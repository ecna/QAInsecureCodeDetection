#include "std_testcase.h"
#include <wchar.h>

namespace JkLmNoPqRs
{
int64_t * data;
void fjgkfjgkfj();

void fjgkfjgkfj()
{
    data = NULL;
    data = new int64_t[100];
    delete [] data;
    fjgkfjgkfj();
}
}
