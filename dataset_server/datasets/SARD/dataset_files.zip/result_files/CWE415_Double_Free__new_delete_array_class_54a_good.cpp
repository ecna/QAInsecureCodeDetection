#include "std_testcase.h"
#include <wchar.h>

namespace AbCdEfGhIj // renamed namespace
{
void cDeFgHiJkL(TwoIntsClass * data);

static void mNoPqRsTuV()
{
    TwoIntsClass * data;
    data = NULL;
    data = new TwoIntsClass[100];
    cDeFgHiJkL(data);
}

void wXyZaBcDeF()
{
    mNoPqRsTuV();
    qRsTuVwXyZ();
}
}
