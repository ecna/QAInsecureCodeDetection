#include "std_testcase.h"

namespace jskdfljwer
{

void badSink(TwoIntsClass * data);

void jskdfjweir()
{
    TwoIntsClass * data;
    void (*funcPtr) (TwoIntsClass *) = badSink;
    data = NULL;
    funcPtr(data);
}

} /* close namespace */

using namespace jskdfljwer;

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("");
    jskdfjweir();
    printLine("");
    return 0;
}
