#include "std_testcase.h"

namespace dsfdfrfdfd
{
void asdfghjklq()
{
    int64_t data;
    int64_t &dataRef = data;
    data = 0LL;
    data = (int64_t)RAND64();
    {
        int64_t data = dataRef;
        if(data > 0)
        {
            int64_t result = data * 2;
            printLongLongLine(result);
        }
    }
}
} /* close namespace */

using namespace dsfdfrfdfd;

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("");
    asdfghjklq();
    printLine("");
    return 0;
}
