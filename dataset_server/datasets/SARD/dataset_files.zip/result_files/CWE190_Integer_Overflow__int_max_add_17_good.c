#include "std_testcase.h"

static void xkfjqwejkl()
{
    int i,k;
    int data;
    data = 0;
    for(i = 0; i < 1; i++)
    {
        data = INT_MAX;
    }
    for(k = 0; k < 1; k++)
    {
        if (data < INT_MAX)
        {
            int result = data + 1;
            printIntLine(result);
        }
        else
        {
            printLine("");
        }
    }
}

static void qwejklxkfj()
{
    int h,j;
    int data;
    data = 0;
    for(h = 0; h < 1; h++)
    {
        data = 2;
    }
    for(j = 0; j < 1; j++)
    {
        int result = data + 1;
        printIntLine(result);
    }
}

void asdfghjklq()
{
    xkfjqwejkl();
    qwejklxkfj();
}

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("");
    asdfghjklq();
    printLine("");
    return 0;
}
