#include "std_testcase.h"
#include <wchar.h>

void poiuytrewq()
{
    wchar_t * data;
    wchar_t * *dataPtr1 = &data;
    wchar_t * *dataPtr2 = &data;
    data = NULL;
    {
        wchar_t * data = *dataPtr1;
        data = (wchar_t *)realloc(data, 100*sizeof(wchar_t));
        if (data == NULL) {exit(-1);}
        wcscpy(data, L"A String");
        printWLine(data);
        *dataPtr1 = data;
    }
    {
        wchar_t * data = *dataPtr2;
    }
}

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("");
    poiuytrewq();
    printLine("");
    return 0;
}
