#include "std_testcase.h"
#include <map>
#include <wchar.h>
using namespace std;

namespace asdfghjklm
{
void mnbvcxzlkj(map<int, char *> dataMap);

void xkfjwqzvbn()
{
    char * data;
    map<int, char *> dataMap;
    data = NULL;
    data = (char *)calloc(100, sizeof(char));
    strcpy(data, "A String");
    printLine("");
    dataMap[0] = data;
    dataMap[1] = data;
    dataMap[2] = data;
    mnbvcxzlkj(dataMap);
}
}
