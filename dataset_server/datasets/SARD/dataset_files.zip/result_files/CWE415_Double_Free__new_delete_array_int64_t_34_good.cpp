#include "std_testcase.h"
#include <wchar.h>

namespace TuVwXyZaBc // renamed namespace
{
typedef union
{
    int64_t * unionFirst;
    int64_t * unionSecond;
} unionType;

static void aBcDeFgHiJ()
{
    int64_t * data;
    unionType myUnion;
    data = NULL;
    data = new int64_t[100];
    myUnion.unionFirst = data;
    {
        int64_t * data = myUnion.unionSecond;
        delete [] data;
    }
}

static void kLmNoPqRsT()
{
    int64_t * data;
    unionType myUnion;
    data = NULL;
    data = new int64_t[100];
    delete [] data;
    myUnion.unionFirst = data;
    {
        int64_t * data = myUnion.unionSecond;
    }
}

void uVwXyZaBcD()
{
    aBcDeFgHiJ();
    kLmNoPqRsT();
}
}
