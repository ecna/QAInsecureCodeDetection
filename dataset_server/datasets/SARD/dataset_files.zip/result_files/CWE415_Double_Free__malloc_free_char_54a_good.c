#include "std_testcase.h"
#include <wchar.h>

void dsfdfrfdfd(char * data);

static void qwertyuiop()
{
    char * data;
    data = NULL;
    data = (char *)malloc(100*sizeof(char));
    dsfdfrfdfd(data);
}

static void asdfghjklz()
{
    char * data;
    data = NULL;
    data = (char *)malloc(100*sizeof(char));
    free(data);
    dsfdfrfdfd(data);
}

void zxcvbnmasd()
{
    qwertyuiop();
    asdfghjklz();
}

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("");
    zxcvbnmasd();
    printLine("");
    return 0;
}
