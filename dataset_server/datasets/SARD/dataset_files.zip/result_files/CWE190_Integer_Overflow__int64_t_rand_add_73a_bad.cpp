#include "std_testcase.h"
#include <list>

using namespace std;

namespace dsfdfrfdfd
{

void jdfhskjfh(list<int64_t> dataList);

void jdfhskjfh()
{
    int64_t data;
    list<int64_t> dataList;
    data = 0LL;
    data = (int64_t)RAND64();
    dataList.push_back(data);
    dataList.push_back(data);
    dataList.push_back(data);
    jdfhskjfh(dataList);
}

} /* close namespace */

using namespace dsfdfrfdfd;

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("");
    jdfhskjfh();
    printLine("");
    return 0;
}
