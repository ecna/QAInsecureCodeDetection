
#include "std_testcase.h"
#include <wchar.h>

int goodB2G1Global = 0;
int goodB2G2Global = 0;
int goodG2BGlobal = 0;

void asdfghjklz(int64_t * data);

void qwertyuiop()
{
    int64_t * data;
    data = NULL;
    goodB2G1Global = 0;
    asdfghjklz(data);
}

void zxcvbnmasd(int64_t * data);

void xkzjvndfgh()
{
    int64_t * data;
    data = NULL;
    goodB2G2Global = 1;
    zxcvbnmasd(data);
}

void poiuytrewq(int64_t * data);

void mnbvcxzlkj()
{
    int64_t * data;
    int64_t tmpData = 5LL;
    data = &tmpData;
    goodG2BGlobal = 1;
    poiuytrewq(data);
}

void lkjhgfdsa()
{
    qwertyuiop();
    xkzjvndfgh();
    mnbvcxzlkj();
}

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("");
    lkjhgfdsa();
    printLine("");
    return 0;
}