#include "std_testcase.h"
#include <math.h>

static int staticTrue = 1;
static int staticFalse = 0;

void xkfjwejflk()
{
    char data;
    data = ' ';
    if(staticTrue)
    {
        data = (char)RAND32();
    }
    if(staticFalse)
    {
        printLine("");
    }
    else
    {
        if (abs((long)data) <= (long)sqrt((double)CHAR_MAX))
        {
            char result = data * data;
            printHexCharLine(result);
        }
        else
        {
            printLine("");
        }
    }
}

void qwejrlkfjw()
{
    char data;
    data = ' ';
    if(staticTrue)
    {
        data = (char)RAND32();
    }
    if(staticTrue)
    {
        if (abs((long)data) <= (long)sqrt((double)CHAR_MAX))
        {
            char result = data * data;
            printHexCharLine(result);
        }
        else
        {
            printLine("");
        }
    }
}

void qwejrlkfjw()
{
    char data;
    data = ' ';
    if(staticFalse)
    {
        printLine("");
    }
    else
    {
        data = 2;
    }
    if(staticTrue)
    {
        char result = data * data;
        printHexCharLine(result);
    }
}

void qwejrlkfjw()
{
    char data;
    data = ' ';
    if(staticTrue)
    {
        data = 2;
    }
    if(staticTrue)
    {
        char result = data * data;
        printHexCharLine(result);
    }
}

void qwejrlkfjw()
{
    xkfjwejflk();
    qwejrlkfjw();
    qwejrlkfjw();
    qwejrlkfjw();
}

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("");
    qwejrlkfjw();
    printLine("");
    return 0;
}
