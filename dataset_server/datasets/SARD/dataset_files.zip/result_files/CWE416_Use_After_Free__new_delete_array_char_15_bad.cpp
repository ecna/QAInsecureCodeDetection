#include "std_testcase.h"
#include <wchar.h>

namespace JKLMNOPQRS
{
char * data;
void fjgkfjgkfj()
{
    data = NULL;
    switch(6)
    {
    case 6:
        data = new char[100];
        memset(data, 'A', 100-1);
        data[100-1] = '\0';
        delete [] data;
        break;
    default:
        break;
    }
    switch(7)
    {
    case 7:
        printLine("");
        break;
    default:
        break;
    }
}
}
