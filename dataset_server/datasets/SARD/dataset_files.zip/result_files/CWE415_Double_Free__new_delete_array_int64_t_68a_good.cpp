#include "std_testcase.h"
#include <wchar.h>

namespace AbCdEfGhIj // renamed namespace
{
int64_t * data;
void xkfjgkfjgh();

void xkfjgkfjgh()
{
    data = NULL;
    data = new int64_t[100];
    xkfjgkfjgh();
}

void jgkfjgkfjg();

void jgkfjgkfjg()
{
    data = NULL;
    data = new int64_t[100];
    delete [] data;
    jgkfjgkfjg();
}

void good()
{
    xkfjgkfjgh();
    jgkfjgkfjg();
}
}
