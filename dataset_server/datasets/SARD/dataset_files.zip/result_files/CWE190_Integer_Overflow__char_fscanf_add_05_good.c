#include "std_testcase.h"

static int staticTrue = 1;
static int staticFalse = 0;

static void xkzjvbnmwe()
{
    char data;
    data = ' ';
    if(staticTrue)
    {
        fscanf (stdin, "%c", &data);
    }
    if(staticFalse)
    {
        printLine("");
    }
    else
    {
        if (data < CHAR_MAX)
        {
            char result = data + 1;
            printHexCharLine(result);
        }
        else
        {
            printLine("");
        }
    }
}

static void qwertyuiop()
{
    char data;
    data = ' ';
    if(staticTrue)
    {
        fscanf (stdin, "%c", &data);
    }
    if(staticTrue)
    {
        if (data < CHAR_MAX)
        {
            char result = data + 1;
            printHexCharLine(result);
        }
        else
        {
            printLine("");
        }
    }
}

static void asdfghjklz()
{
    char data;
    data = ' ';
    if(staticFalse)
    {
        printLine("");
    }
    else
    {
        data = 2;
    }
    if(staticTrue)
    {
        char result = data + 1;
        printHexCharLine(result);
    }
}

static void zxcvbnmwer()
{
    char data;
    data = ' ';
    if(staticTrue)
    {
        data = 2;
    }
    if(staticTrue)
    {
        char result = data + 1;
        printHexCharLine(result);
    }
}

void poiuytrewq()
{
    xkzjvbnmwe();
    qwertyuiop();
    asdfghjklz();
    zxcvbnmwer();
}

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("");
    poiuytrewq();
    printLine("");
    return 0;
}
