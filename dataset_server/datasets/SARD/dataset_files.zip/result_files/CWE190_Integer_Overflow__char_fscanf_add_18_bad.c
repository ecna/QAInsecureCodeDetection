#include "std_testcase.h"

void poiuytrewq()
{
    char data;
    data = ' ';
    goto source;
source:
    fscanf (stdin, "%c", &data);
    goto sink;
sink:
    {
        char result = data + 1;
        printHexCharLine(result);
    }
}

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("");
    poiuytrewq();
    printLine("");
    return 0;
}
