#include "std_testcase.h"

static int staticTrue = 1;
static int staticFalse = 0;

namespace xkfjrjvlsd
{

void jskdfjweir()
{
    TwoIntsClass * data;
    if(staticTrue)
    {
        data = NULL;
    }
    if(staticTrue)
    {
        printIntLine(data->intOne);
        delete data;
    }
}

} /* close namespace */

using namespace xkfjrjvlsd;

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("");
    jskdfjweir();
    printLine("");
    return 0;
}
