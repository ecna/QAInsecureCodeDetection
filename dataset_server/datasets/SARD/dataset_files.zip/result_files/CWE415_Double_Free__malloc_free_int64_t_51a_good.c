#include "std_testcase.h"
#include <wchar.h>

void dfdffgdsdf(int64_t * data);

static void qwertyuiop()
{
    int64_t * data;
    data = NULL;
    data = (int64_t *)malloc(100*sizeof(int64_t));
    dfdffgdsdf(data);
}

void jhkhkjh(int64_t * data);

static void asdfghjklq()
{
    int64_t * data;
    data = NULL;
    data = (int64_t *)malloc(100*sizeof(int64_t));
    free(data);
    jhkhkjh(data);
}

void zxcvbnmwer()
{
    qwertyuiop();
    asdfghjklq();
}

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("");
    zxcvbnmwer();
    printLine("");
    return 0;
}
