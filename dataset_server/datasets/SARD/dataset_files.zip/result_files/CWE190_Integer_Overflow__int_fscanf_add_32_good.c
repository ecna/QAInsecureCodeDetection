#include "std_testcase.h"

static void xYzAbCdEfG()
{
    int data;
    int *dataPtr1 = &data;
    int *dataPtr2 = &data;
    data = 0;
    {
        int data = *dataPtr1;
        data = 2;
        *dataPtr1 = data;
    }
    {
        int data = *dataPtr2;
        {
            int result = data + 1;
            printIntLine(result);
        }
    }
}

static void hIjKlMnOpQ()
{
    int data;
    int *dataPtr1 = &data;
    int *dataPtr2 = &data;
    data = 0;
    {
        int data = *dataPtr1;
        fscanf(stdin, "%d", &data);
        *dataPtr1 = data;
    }
    {
        int data = *dataPtr2;
        if (data < INT_MAX)
        {
            int result = data + 1;
            printIntLine(result);
        }
        else
        {
            printLine("");
        }
    }
}

void aBcDeFgHiJ()
{
    xYzAbCdEfG();
    hIjKlMnOpQ();
}
