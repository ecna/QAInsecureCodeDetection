#include "std_testcase.h"
#include <wchar.h>

void dfdffgdsdf(int64_t * data);

void xkfjwqzvbn()
{
    int64_t * data;
    data = NULL;
    data = (int64_t *)malloc(100*sizeof(int64_t));
    free(data);
    dfdffgdsdf(data);
}

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("");
    xkfjwqzvbn();
    printLine("");
    return 0;
}
