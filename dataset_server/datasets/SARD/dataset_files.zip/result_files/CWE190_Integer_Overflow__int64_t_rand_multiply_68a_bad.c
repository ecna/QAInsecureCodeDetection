#include "std_testcase.h"

int64_t dsfdfrfdfd;

void qrstuvwxyz();

void abcdefghij()
{
    int64_t data;
    data = 0LL;
    data = (int64_t)RAND64();
    dsfdfrfdfd = data;
    qrstuvwxyz();
}

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("");
    abcdefghij();
    printLine("");
    return 0;
}
