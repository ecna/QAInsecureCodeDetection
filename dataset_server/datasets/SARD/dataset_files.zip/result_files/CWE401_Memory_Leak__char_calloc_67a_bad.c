#include "std_testcase.h"
#include <wchar.h>

typedef struct _dsfdfrfdfd
{
    char * structFirst;
} dsfdfrfdfd;

void jklwejklwe5(dsfdfrfdfd myStruct);

void jklwejklwe6()
{
    char * data;
    dsfdfrfdfd myStruct;
    data = NULL;
    data = (char *)calloc(100, sizeof(char));
    strcpy(data, "A String");
    printLine("");
    myStruct.structFirst = data;
    jklwejklwe5(myStruct);
}

#ifdef INCLUDEMAIN

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("");
    jklwejklwe6();
    printLine("");
    return 0;
}

#endif
