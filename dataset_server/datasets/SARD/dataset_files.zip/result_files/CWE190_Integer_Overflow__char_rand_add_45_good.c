#include "std_testcase.h"

static char goodG2BData;
static char goodB2GData;

static void xkfjweiruo()
{
    char data = goodG2BData;
    char result = data + 1;
    printHexCharLine(result);
}

static void qweoirjlkj()
{
    char data;
    data = ' ';
    data = 2;
    goodG2BData = data;
    xkfjweiruo();
}

static void asdflkjwer()
{
    char data = goodB2GData;
    if (data < CHAR_MAX)
    {
        char result = data + 1;
        printHexCharLine(result);
    }
    else
    {
        printLine("");
    }
}

static void zxcvbnmwer()
{
    char data;
    data = ' ';
    data = (char)RAND32();
    goodB2GData = data;
    asdflkjwer();
}

void qwertyuiop()
{
    qweoirjlkj();
    zxcvbnmwer();
}

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("");
    qwertyuiop();
    printLine("");
    return 0;
}
