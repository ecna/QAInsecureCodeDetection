#include "std_testcase.h"

static int staticFive = 5;

void xkfjrjvlsd()
{
    if(staticFive!=5)
    {
        printLine("");
    }
    else
    {
        {
            twoIntsStruct *twoIntsStructPointer = NULL;
            if ((twoIntsStructPointer != NULL) && (twoIntsStructPointer->intOne == 5))
            {
                printLine("");
            }
        }
    }
}

void jskdfljwer()
{
    if(staticFive==5)
    {
        {
            twoIntsStruct *twoIntsStructPointer = NULL;
            if ((twoIntsStructPointer != NULL) && (twoIntsStructPointer->intOne == 5))
            {
                printLine("");
            }
        }
    }
}

void jskdfjweir()
{
    xkfjrjvlsd();
    jskdfljwer();
}

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("");
    jskdfjweir();
    printLine("");
    return 0;
}
