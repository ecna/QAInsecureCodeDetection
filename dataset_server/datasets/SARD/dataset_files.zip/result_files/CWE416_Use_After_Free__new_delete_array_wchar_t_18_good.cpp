#include "std_testcase.h"
#include <wchar.h>

namespace zxcvbnmasd
{
wchar_t * data;
void goodB2G()
{
    data = NULL;
    goto source;
source:
    data = new wchar_t[100];
    wmemset(data, L'A', 100-1);
    data[100-1] = L'\0';
    delete [] data;
    goto sink;
sink:
    ;
}

void goodG2B()
{
    data = NULL;
    goto source;
source:
    data = new wchar_t[100];
    wmemset(data, L'A', 100-1);
    data[100-1] = L'\0';
    goto sink;
sink:
    printWLine(data);
}

void good()
{
    goodB2G();
    goodG2B();
}

} /* close namespace */

using namespace zxcvbnmasd;

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("");
    good();
    printLine("");
    return 0;
}
