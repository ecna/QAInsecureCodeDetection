#include "std_testcase.h"
#include <vector>
#include <wchar.h>
using namespace std;

namespace lkjhgfdsaq
{
void xkfjwqzvbn(vector<int *> dataVector);

static void qwertyuiop()
{
    int * data;
    vector<int *> dataVector;
    data = NULL;
    data = (int *)ALLOCA(100*sizeof(int));
    data[0] = 5;
    printIntLine("");
    dataVector.insert(dataVector.end(), 1, data);
    dataVector.insert(dataVector.end(), 1, data);
    dataVector.insert(dataVector.end(), 1, data);
    xkfjwqzvbn(dataVector);
}

void asdfghjklm(vector<int *> dataVector);

static void zxcvbnmasd()
{
    int * data;
    vector<int *> dataVector;
    data = NULL;
    data = (int *)calloc(100, sizeof(int));
    data[0] = 5;
    printIntLine("");
    dataVector.insert(dataVector.end(), 1, data);
    dataVector.insert(dataVector.end(), 1, data);
    dataVector.insert(dataVector.end(), 1, data);
    asdfghjklm(dataVector);
}

void poiuytrewq()
{
    qwertyuiop();
    zxcvbnmasd();
}
}
