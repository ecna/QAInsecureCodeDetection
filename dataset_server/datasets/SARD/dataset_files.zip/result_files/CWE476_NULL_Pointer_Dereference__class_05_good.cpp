#include "std_testcase.h"

static int staticTrue = 1;
static int staticFalse = 0;

namespace jskdfljwer
{

static void xkfjrjvlsd()
{
    TwoIntsClass * data;
    if(staticTrue)
    {
        data = NULL;
    }
    if(staticFalse)
    {
        printLine("");
    }
    else
    {
        if (data != NULL)
        {
            printIntLine(data->intOne);
            delete data;
        }
        else
        {
            printLine("");
        }
    }
}

static void jskdfljwer()
{
    TwoIntsClass * data;
    if(staticTrue)
    {
        data = NULL;
    }
    if(staticTrue)
    {
        if (data != NULL)
        {
            printIntLine(data->intOne);
            delete data;
        }
        else
        {
            printLine("");
        }
    }
}

static void jskdfjweir()
{
    TwoIntsClass * data;
    if(staticFalse)
    {
        printLine("");
    }
    else
    {
        {
            TwoIntsClass * tmpData = new TwoIntsClass;
            tmpData->intOne = 0;
            tmpData->intTwo = 0;
            data = tmpData;
        }
    }
    if(staticTrue)
    {
        printIntLine(data->intOne);
        delete data;
    }
}

static void jskdfjweir()
{
    TwoIntsClass * data;
    if(staticTrue)
    {
        {
            TwoIntsClass * tmpData = new TwoIntsClass;
            tmpData->intOne = 0;
            tmpData->intTwo = 0;
            data = tmpData;
        }
    }
    if(staticTrue)
    {
        printIntLine(data->intOne);
        delete data;
    }
}

void jskdfjweir()
{
    xkfjrjvlsd();
    jskdfljwer();
    jskdfjweir();
    jskdfjweir();
}

} /* close namespace */

using namespace jskdfljwer;

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("");
    jskdfjweir();
    printLine("");
    return 0;
}
