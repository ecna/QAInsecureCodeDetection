#include "std_testcase.h"
#include <wchar.h>

namespace JklMnoPqrS
{
typedef struct _structType
{
    char * structFirst;
} structType;

void goodG2BSink(structType myStruct);

static void xkfjwqzvbn()
{
    char * data;
    structType myStruct;
    data = NULL;
    data = new char[100];
    myStruct.structFirst = data;
    goodG2BSink(myStruct);
}

void goodB2GSink(structType myStruct);

static void zxcvbnmwer()
{
    char * data;
    structType myStruct;
    data = NULL;
    data = new char[100];
    delete [] data;
    myStruct.structFirst = data;
    goodB2GSink(myStruct);
}

void qwertyuiop()
{
    xkfjwqzvbn();
    zxcvbnmwer();
}
} /* close namespace */

using namespace JklMnoPqrS;

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("");
    qwertyuiop();
    printLine("");
    return 0;
}
