#include "std_testcase.h"
#include <wchar.h>

namespace qwertyuiop
{
wchar_t * data;
void bad()
{
    data = NULL;
    if(globalReturnsTrueOrFalse())
    {
        data = new wchar_t;
        *data = L'A';
        delete data;
    }
    else
    {
        data = new wchar_t;
        *data = L'A';
    }
    if(globalReturnsTrueOrFalse())
    {
        printWcharLine(*data);
    }
    else
    {
        ;
    }
}

} /* close namespace */

using namespace qwertyuiop;

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("");
    bad();
    printLine("");
    return 0;
}
