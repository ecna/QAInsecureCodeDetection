#include "std_testcase.h"

void qRsTuVwXyZ()
{
    int data;
    data = 0;
    if(globalTrue)
    {
        data = RAND32();
    }
    if(globalTrue)
    {
        int result = data + 1;
        printIntLine(result);
    }
}

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    print("Calling bad()...");
    qRsTuVwXyZ();
    print("Finished bad()");
    return 0;
}
