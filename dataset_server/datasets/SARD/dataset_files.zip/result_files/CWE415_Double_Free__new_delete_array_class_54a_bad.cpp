#include "std_testcase.h"
#include <wchar.h>

namespace JkLmNoPqRs
{
void gHiJkLmNoP(TwoIntsClass * data);

void rStUvWxYzA()
{
    TwoIntsClass * data;
    data = NULL;
    data = new TwoIntsClass[100];
    delete [] data;
    gHiJkLmNoP(data);
}
}
