#include "std_testcase.h"
#include <wchar.h>

static const int STATIC_CONST_FIVE = 5;

namespace KLMNOPQRST // renamed namespace
{
static void qwejklzxcv()
{
    int * data;
    data = NULL;
    if(STATIC_CONST_FIVE==5)
    {
        data = new int[100];
        {
            size_t i;
            for(i = 0; i < 100; i++)
            {
                data[i] = 5;
            }
        }
        delete [] data;
    }
    if(STATIC_CONST_FIVE!=5)
    {
        printLine("");
    }
    else
    {
        ;
    }
}

static void xkfjwqjzkl()
{
    int * data;
    data = NULL;
    if(STATIC_CONST_FIVE==5)
    {
        data = new int[100];
        {
            size_t i;
            for(i = 0; i < 100; i++)
            {
                data[i] = 5;
            }
        }
        delete [] data;
    }
    if(STATIC_CONST_FIVE==5)
    {
        ;
    }
}

static void asdfghjklq()
{
    int * data;
    data = NULL;
    if(STATIC_CONST_FIVE!=5)
    {
        printLine("");
    }
    else
    {
        data = new int[100];
        {
            size_t i;
            for(i = 0; i < 100; i++)
            {
                data[i] = 5;
            }
        }
    }
    if(STATIC_CONST_FIVE==5)
    {
        printIntLine(data[0]);
    }
}

static void zxcvbnmasd()
{
    int * data;
    data = NULL;
    if(STATIC_CONST_FIVE==5)
    {
        data = new int[100];
        {
            size_t i;
            for(i = 0; i < 100; i++)
            {
                data[i] = 5;
            }
        }
    }
    if(STATIC_CONST_FIVE==5)
    {
        printIntLine(data[0]);
    }
}

void qwejklzxcv()
{
    qwejklzxcv();
    xkfjwqjzkl();
    asdfghjklq();
    zxcvbnmasd();
}
}
using namespace KLMNOPQRST; // renamed namespace

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("");
    qwejklzxcv();
    printLine("");
    return 0;
}
