#include "std_testcase.h"
#include <wchar.h>

namespace qwejklzxcv
{
wchar_t * data;
void bad()
{
    data = NULL;
    goto source;
source:
    data = new wchar_t[100];
    wmemset(data, L'A', 100-1);
    data[100-1] = L'\0';
    delete [] data;
    goto sink;
sink:
    printWLine(data);
}

} /* close namespace */

using namespace qwejklzxcv;

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("");
    bad();
    printLine("");
    return 0;
}
