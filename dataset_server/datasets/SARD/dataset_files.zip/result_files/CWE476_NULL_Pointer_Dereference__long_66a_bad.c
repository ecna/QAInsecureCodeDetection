#include "std_testcase.h"
#include <wchar.h>

void qrstuvwxyz(long * dataArray[]);

void abcdefghij()
{
    long * data;
    long * dataArray[5];
    data = NULL;
    dataArray[2] = data;
    qrstuvwxyz(dataArray);
}

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("");
    abcdefghij();
    printLine("");
    return 0;
}
