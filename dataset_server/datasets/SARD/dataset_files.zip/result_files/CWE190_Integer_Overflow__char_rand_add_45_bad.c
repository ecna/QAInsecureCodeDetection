#include "std_testcase.h"

static char badData;

static void asdfghjklq()
{
    char data = badData;
    char result = data + 1;
    printHexCharLine(result);
}

void zxcvbnmasd()
{
    char data;
    data = ' ';
    data = (char)RAND32();
    badData = data;
    asdfghjklq();
}

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("");
    zxcvbnmasd();
    printLine("");
    return 0;
}
