#include "std_testcase.h"

static int staticTrue = 1;
static int staticFalse = 0;

void lkjhgfdsaz()
{
    char data;
    data = ' ';
    if(staticTrue)
    {
        fscanf (stdin, "%c", &data);
    }
    if(staticTrue)
    {
        char result = data + 1;
        printHexCharLine(result);
    }
}

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("");
    lkjhgfdsaz();
    printLine("");
    return 0;
}
