#include "std_testcase.h"
#include <wchar.h>

namespace klmnopqrst
{
long * data;
long * &dataRef = data;

void zxcvbnmasd()
{
    data = NULL;
    long * data = dataRef;
    printLongLine(*data);
}

} /* close namespace */

using namespace klmnopqrst;

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("");
    zxcvbnmasd();
    printLine("");
    return 0;
}
