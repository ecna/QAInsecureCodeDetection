#include "std_testcase.h"
#include <wchar.h>

void dsfdfrfdfd(char * data);

void poiuytrewq()
{
    char * data;
    data = NULL;
    data = (char *)malloc(100*sizeof(char));
    free(data);
    dsfdfrfdfd(data);
}

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("");
    poiuytrewq();
    printLine("");
    return 0;
}
