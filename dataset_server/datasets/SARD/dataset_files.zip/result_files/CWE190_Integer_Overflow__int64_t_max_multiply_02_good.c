#include "std_testcase.h"

void xkfjwejzlk()
{
    int64_t data;
    data = 0LL;
    if(1)
    {
        data = LLONG_MAX;
    }
    if(0)
    {
        printLine("");
    }
    else
    {
        if(data > 0)
        {
            if (data < (LLONG_MAX/2))
            {
                int64_t result = data * 2;
                printLongLongLine(result);
            }
            else
            {
                printLine("");
            }
        }
    }
}

void qwejklzxcv()
{
    int64_t data;
    data = 0LL;
    if(1)
    {
        data = LLONG_MAX;
    }
    if(1)
    {
        if(data > 0)
        {
            if (data < (LLONG_MAX/2))
            {
                int64_t result = data * 2;
                printLongLongLine(result);
            }
            else
            {
                printLine("");
            }
        }
    }
}

void asdfghjklq()
{
    int64_t data;
    data = 0LL;
    if(0)
    {
        printLine("");
    }
    else
    {
        data = 2;
    }
    if(1)
    {
        if(data > 0)
        {
            int64_t result = data * 2;
            printLongLongLine(result);
        }
    }
}

void zxcvbnmasd()
{
    int64_t data;
    data = 0LL;
    if(1)
    {
        data = 2;
    }
    if(1)
    {
        if(data > 0)
        {
            int64_t result = data * 2;
            printLongLongLine(result);
        }
    }
}

void qwertyuiop()
{
    xkfjwejzlk();
    qwejklzxcv();
    asdfghjklq();
    zxcvbnmasd();
}

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("");
    qwertyuiop();
    printLine("");
    return 0;
}
