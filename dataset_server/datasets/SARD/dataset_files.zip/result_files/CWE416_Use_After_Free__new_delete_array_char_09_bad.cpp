#include "std_testcase.h"
#include <wchar.h>

namespace DEFGHIJKLM
{
char * data;
void fjgkfjgkfj()
{
    data = NULL;
    if(GLOBAL_CONST_TRUE)
    {
        data = new char[100];
        memset(data, 'A', 100-1);
        data[100-1] = '\0';
        delete [] data;
    }
    if(GLOBAL_CONST_TRUE)
    {
        printLine("");
    }
}
}
