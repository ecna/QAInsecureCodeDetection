#include "std_testcase.h"

void qRsTuVwXyZ()
{
    int data;
    int *dataPtr1 = &data;
    int *dataPtr2 = &data;
    data = 0;
    {
        int data = *dataPtr1;
        fscanf(stdin, "%d", &data);
        *dataPtr1 = data;
    }
    {
        int data = *dataPtr2;
        {
            int result = data + 1;
            printIntLine(result);
        }
    }
}
