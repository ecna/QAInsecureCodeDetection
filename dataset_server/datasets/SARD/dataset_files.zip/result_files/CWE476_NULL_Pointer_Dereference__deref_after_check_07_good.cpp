#include "std_testcase.h"
#include <wchar.h>

void asdfghjklz()
{
    if(staticFive!=5)
    {
        printLine("");
    }
    else
    {
        int *intPointer = NULL;
        if (intPointer == NULL)
        {
            printLine("");
        }
    }
}

void qwertyuiop()
{
    if(staticFive==5)
    {
        int *intPointer = NULL;
        if (intPointer == NULL)
        {
            printLine("");
        }
    }
}

void zxcvbnmasd()
{
    asdfghjklz();
    qwertyuiop();
}

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("");
    zxcvbnmasd();
    printLine("");
    return 0;
}