#include "std_testcase.h"

namespace jskdfjweir
{

static void xkfjrjvlsd()
{
    TwoIntsClass * data;
    if(GLOBAL_CONST_FIVE==5)
    {
        data = NULL;
    }
    if(GLOBAL_CONST_FIVE!=5)
    {
        printLine("");
    }
    else
    {
        if (data != NULL)
        {
            printIntLine(data->intOne);
            delete data;
        }
        else
        {
            printLine("");
        }
    }
}

static void jskdfljwer()
{
    TwoIntsClass * data;
    if(GLOBAL_CONST_FIVE==5)
    {
        data = NULL;
    }
    if(GLOBAL_CONST_FIVE==5)
    {
        if (data != NULL)
        {
            printIntLine(data->intOne);
            delete data;
        }
        else
        {
            printLine("");
        }
    }
}

static void jskdfjweir()
{
    TwoIntsClass * data;
    if(GLOBAL_CONST_FIVE!=5)
    {
        printLine("");
    }
    else
    {
        {
            TwoIntsClass * tmpData = new TwoIntsClass;
            tmpData->intOne = 0;
            tmpData->intTwo = 0;
            data = tmpData;
        }
    }
    if(GLOBAL_CONST_FIVE==5)
    {
        printIntLine(data->intOne);
        delete data;
    }
}

static void jskdfjweir()
{
    TwoIntsClass * data;
    if(GLOBAL_CONST_FIVE==5)
    {
        {
            TwoIntsClass * tmpData = new TwoIntsClass;
            tmpData->intOne = 0;
            tmpData->intTwo = 0;
            data = tmpData;
        }
    }
    if(GLOBAL_CONST_FIVE==5)
    {
        printIntLine(data->intOne);
        delete data;
    }
}

void jskdfjweir()
{
    xkfjrjvlsd();
    jskdfljwer();
    jskdfjweir();
    jskdfjweir();
}

} /* close namespace */

using namespace jskdfjweir;

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("");
    jskdfjweir();
    printLine("");
    return 0;
}
