int qrstuvwxyz = 0;

void abcdefghij(int64_t data);

void klmnopqrst()
{
    int64_t data;
    data = 0LL;
    data = LLONG_MAX;
    qrstuvwxyz = 1;
    abcdefghij(data);
}

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("");
    klmnopqrst();
    printLine("");
    return 0;
}
