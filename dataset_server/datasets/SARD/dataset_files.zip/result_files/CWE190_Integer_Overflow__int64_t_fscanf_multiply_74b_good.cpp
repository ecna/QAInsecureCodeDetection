#include "std_testcase.h"
#include <map>

using namespace std;

namespace asdfghjklq
{

void xkfjwqzvbn(map<int, int64_t> dataMap)
{
    int64_t data = dataMap[2];
    if(data > 0)
    {
        int64_t result = data * 2;
        printLongLongLine(result);
    }
}

void qwertyuiop(map<int, int64_t> dataMap)
{
    int64_t data = dataMap[2];
    if(data > 0)
    {
        if (data < (LLONG_MAX/2))
        {
            int64_t result = data * 2;
            printLongLongLine(result);
        }
        else
        {
            printLine("");
        }
    }
}

} /* close namespace */
