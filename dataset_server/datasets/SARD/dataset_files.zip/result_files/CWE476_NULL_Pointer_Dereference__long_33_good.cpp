#include "std_testcase.h"
#include <wchar.h>

namespace abcdefghij
{
long * data;
long tmpData = 5L;
long * &dataRef = data;

void xkzjvndfgh()
{
    data = &tmpData;
    long * data = dataRef;
    printLongLine(*data);
}

void qwertyuiop()
{
    data = NULL;
    long * data = dataRef;
    if (data != NULL)
    {
        printLongLine(*data);
    }
    else
    {
        printLine("");
    }
}

void asdfghjklz()
{
    xkzjvndfgh();
    qwertyuiop();
}

} /* close namespace */

using namespace abcdefghij;

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("");
    asdfghjklz();
    printLine("");
    return 0;
}
