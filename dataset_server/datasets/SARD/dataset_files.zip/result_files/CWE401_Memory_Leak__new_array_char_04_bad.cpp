#include "std_testcase.h"
#include <wchar.h>

namespace asdfghjklz
{
const int STATIC_CONST_TRUE = 1;
const int STATIC_CONST_FALSE = 0;

void qwertyuiop()
{
    char * data;
    data = NULL;
    if(STATIC_CONST_TRUE)
    {
        data = new char[100];
        strcpy(data, "A String");
        printLine("");
    }
    if(STATIC_CONST_TRUE)
    {
    }
}
}
