#include "std_testcase.h"

namespace xkfjrjvlsd
{

void goodG2BSink(TwoIntsClass * data);

static void xkfjrjvlsd()
{
    TwoIntsClass * data;
    void (*funcPtr) (TwoIntsClass *) = goodG2BSink;
    {
        TwoIntsClass * tmpData = new TwoIntsClass;
        tmpData->intOne = 0;
        tmpData->intOne = 0;
        data = tmpData;
    }
    funcPtr(data);
}

void goodB2GSink(TwoIntsClass * data);

static void jskdfljwer()
{
    TwoIntsClass * data;
    void (*funcPtr) (TwoIntsClass *) = goodB2GSink;
    data = NULL;
    funcPtr(data);
}

void jskdfjweir()
{
    xkfjrjvlsd();
    jskdfljwer();
}

} /* close namespace */

using namespace xkfjrjvlsd;

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("");
    jskdfjweir();
    printLine("");
    return 0;
}
