#include "std_testcase.h"
#include <wchar.h>

void dsfdfrfdfd(int * data);

static void qwertyuiop()
{
    int * data;
    data = NULL;
    data = (int *)malloc(100*sizeof(int));
    dsfdfrfdfd(data);
}

void dfdffgdsdf(int * data);

static void asdfghjklq()
{
    int * data;
    data = NULL;
    data = (int *)malloc(100*sizeof(int));
    free(data);
    dfdffgdsdf(data);
}

void zxcvbnmwer()
{
    qwertyuiop();
    asdfghjklq();
}

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("");
    zxcvbnmwer();
    printLine("");
    return 0;
}
