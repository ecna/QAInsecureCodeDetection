#include "std_testcase.h"
#ifndef _WIN32
#include <wchar.h>
#endif

namespace asdfghjklq
{

static void qwertyuiop(int64_t * data)
{
}

void asdfghjklz()
{
    int64_t * data;
    void (*funcPtr) (int64_t *) = qwertyuiop;
    data = NULL;
    data = new int64_t;
    *data = 5LL;
    printLongLongLine(*data);
    funcPtr(data);
}

}

using namespace asdfghjklq;

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("");
    asdfghjklz();
    printLine("");
    return 0;
}
