#include "std_testcase.h"
#include <wchar.h>

namespace zxcvbnmasd
{
int64_t * data;
int64_t * *dataPtr1 = &data;
int64_t * *dataPtr2 = &data;

void poiuytrewq()
{
    data = NULL;
    {
        int64_t * data = *dataPtr1;
        data = new int64_t[100];
        data[0] = 5LL;
        printLongLongLine(data[0]);
        *dataPtr1 = data;
    }
    {
        int64_t * data = *dataPtr2;
    }
}
}
