#include "std_testcase.h"
#include <wchar.h>

namespace qwertyuiop
{
void qwejklzxcv(int * * dataPtr);

void xkfjwqjzkl()
{
    int * data;
    data = NULL;
    data = new int[100];
    {
        size_t i;
        for(i = 0; i < 100; i++)
        {
            data[i] = 5;
        }
    }
    delete [] data;
    qwejklzxcv(&data);
}
}
using namespace qwertyuiop;

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("");
    xkfjwqjzkl();
    printLine("");
    return 0;
}
