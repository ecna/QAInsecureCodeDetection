#include "std_testcase.h"

static int staticFive = 5;

void jskdfjweir()
{
    if(staticFive==5)
    {
        {
            twoIntsStruct *twoIntsStructPointer = NULL;
            if ((twoIntsStructPointer != NULL) & (twoIntsStructPointer->intOne == 5))
            {
                printLine("");
            }
        }
    }
}

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("");
    jskdfjweir();
    printLine("");
    return 0;
}
