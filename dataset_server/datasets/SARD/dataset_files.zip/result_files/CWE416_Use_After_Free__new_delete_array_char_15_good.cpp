#include "std_testcase.h"
#include <wchar.h>

namespace YZABCDEFGHI // renamed namespace
{
char * data;
void xkfjgkfjgh()
{
    data = NULL;
    switch(6)
    {
    case 6:
        data = new char[100];
        memset(data, 'A', 100-1);
        data[100-1] = '\0';
        delete [] data;
        break;
    default:
        break;
    }
    switch(8)
    {
    case 7:
        break;
    default:
        ;
        break;
    }
}

void jgkfjgkfjg()
{
    data = NULL;
    switch(6)
    {
    case 6:
        data = new char[100];
        memset(data, 'A', 100-1);
        data[100-1] = '\0';
        delete [] data;
        break;
    default:
        break;
    }
    switch(7)
    {
    case 7:
        ;
        break;
    default:
        break;
    }
}

void fjgkfjgkfj()
{
    data = NULL;
    switch(5)
    {
    case 6:
        break;
    default:
        data = new char[100];
        memset(data, 'A', 100-1);
        data[100-1] = '\0';
        break;
    }
    switch(7)
    {
    case 7:
        printLine("");
        break;
    default:
        break;
    }
}

void kfjgkfjgkf()
{
    data = NULL;
    switch(6)
    {
    case 6:
        data = new char[100];
        memset(data, 'A', 100-1);
        data[100-1] = '\0';
        break;
    default:
        break;
    }
    switch(7)
    {
    case 7:
        printLine("");
        break;
    default:
        break;
    }
}

void good()
{
    xkfjgkfjgh();
    jgkfjgkfjg();
    fjgkfjgkfj();
    kfjgkfjgkf();
}
}
