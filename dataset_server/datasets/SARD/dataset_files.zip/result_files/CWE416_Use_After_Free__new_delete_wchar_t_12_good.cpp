#include "std_testcase.h"
#include <wchar.h>

namespace jskdfjweir
{
wchar_t * data;
void goodB2G()
{
    data = NULL;
    if(globalReturnsTrueOrFalse())
    {
        data = new wchar_t;
        *data = L'A';
        delete data;
    }
    else
    {
        data = new wchar_t;
        *data = L'A';
        delete data;
    }
    if(globalReturnsTrueOrFalse())
    {
        ;
    }
    else
    {
        ;
    }
}

void goodG2B()
{
    data = NULL;
    if(globalReturnsTrueOrFalse())
    {
        data = new wchar_t;
        *data = L'A';
    }
    else
    {
        data = new wchar_t;
        *data = L'A';
    }
    if(globalReturnsTrueOrFalse())
    {
        printWcharLine(*data);
    }
    else
    {
        printWcharLine(*data);
    }
}

void good()
{
    goodB2G();
    goodG2B();
}

} /* close namespace */

using namespace jskdfjweir;

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("");
    good();
    printLine("");
    return 0;
}
