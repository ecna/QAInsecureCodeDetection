#include "std_testcase.h"
#include <list>

using namespace std;

namespace dsfdfrfdfd
{

void xkfjruehwi(list<int64_t> dataList);

static void jdkfhsjdf()
{
    int64_t data;
    list<int64_t> dataList;
    data = 0LL;
    data = 2;
    dataList.push_back(data);
    dataList.push_back(data);
    dataList.push_back(data);
    xkfjruehwi(dataList);
}

void jdfhskjfh(list<int64_t> dataList);

static void jdfhskjfh()
{
    int64_t data;
    list<int64_t> dataList;
    data = 0LL;
    data = (int64_t)RAND64();
    dataList.push_back(data);
    dataList.push_back(data);
    dataList.push_back(data);
    jdfhskjfh(dataList);
}

void jdfhskjfh()
{
    jdkfhsjdf();
    jdfhskjfh();
}

} /* close namespace */

using namespace dsfdfrfdfd;

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("");
    jdfhskjfh();
    printLine("");
    return 0;
}
