
#include "std_testcase.h"
#include <wchar.h>

void lkjhgfdsaz(long * dataArray[]);

void xkfjwqzvbn()
{
    long * data;
    long * dataArray[5];
    data = NULL;
    dataArray[2] = data;
    lkjhgfdsaz(dataArray);
}