#include "std_testcase.h"
#include <wchar.h>

namespace RsTuVwXyZa
{
void sTuVwXyZaB()
{
    int64_t * data;
    int64_t * *dataPtr1 = &data;
    int64_t * *dataPtr2 = &data;
    data = NULL;
    {
        int64_t * data = *dataPtr1;
        data = new int64_t[100];
        delete [] data;
        *dataPtr1 = data;
    }
    {
        int64_t * data = *dataPtr2;
        delete [] data;
    }
}
}
