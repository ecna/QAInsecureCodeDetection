#include "std_testcase.h"
#include <wchar.h>

namespace dsfdfrfdfd
{
void zxcvbnmwer(char * data)
{
}

void poiuytrewq()
{
    char * data;
    void (*funcPtr) (char *) = zxcvbnmwer;
    data = NULL;
    data = new char[100];
    strcpy(data, "A String");
    printLine("");
    funcPtr(data);
}
}
