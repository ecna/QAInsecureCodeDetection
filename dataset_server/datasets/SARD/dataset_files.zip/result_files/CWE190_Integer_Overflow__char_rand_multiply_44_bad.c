#include "std_testcase.h"

static void lkjhgfdsaz(char data)
{
    if(data > 0)
    {
        char result = data * 2;
        printHexCharLine(result);
    }
}

void mnbvcxzlkj()
{
    char data;
    void (*funcPtr) (char) = lkjhgfdsaz;
    data = ' ';
    data = (char)RAND32();
    funcPtr(data);
}

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("");
    mnbvcxzlkj();
    printLine("");
    return 0;
}
