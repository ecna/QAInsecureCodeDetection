#include "std_testcase.h"
#include <wchar.h>

namespace poiuytrewq
{
void qwertyuiop(char * data)
{
}

void asdfghjklz()
{
    char * data;
    void (*funcPtr) (char *) = qwertyuiop;
    data = NULL;
    char dataGoodBuffer[100];
    data = dataGoodBuffer;
    strcpy(data, "A String");
    printLine("");
    funcPtr(data);
}

void zxcvbnmwer(char * data)
{
    delete[] data;
}

void poiuytrewq()
{
    char * data;
    void (*funcPtr) (char *) = zxcvbnmwer;
    data = NULL;
    data = new char[100];
    strcpy(data, "A String");
    printLine("");
    funcPtr(data);
}

void lkjhgfdsa()
{
    asdfghjklz();
    poiuytrewq();
}
}
