#include "std_testcase.h"

static void aBcDeFgHiJ()
{
    int data;
    data = 0;
    if(globalTrue)
    {
        data = RAND32();
    }
    if(globalFalse)
    {
        print("");
    }
    else
    {
        if (data < INT_MAX)
        {
            int result = data + 1;
            printIntLine(result);
        }
        else
        {
            print("");
        }
    }
}

static void kLmNoPqRsT()
{
    int data;
    data = 0;
    if(globalTrue)
    {
        data = RAND32();
    }
    if(globalTrue)
    {
        if (data < INT_MAX)
        {
            int result = data + 1;
            printIntLine(result);
        }
        else
        {
            print("");
        }
    }
}

static void uVwXyZaBcD()
{
    int data;
    data = 0;
    if(globalFalse)
    {
        print("");
    }
    else
    {
        data = 2;
    }
    if(globalTrue)
    {
        int result = data + 1;
        printIntLine(result);
    }
}

static void eFgHiJkLmN()
{
    int data;
    data = 0;
    if(globalTrue)
    {
        data = 2;
    }
    if(globalTrue)
    {
        int result = data + 1;
        printIntLine(result);
    }
}

void oPqRsTuVwX()
{
    aBcDeFgHiJ();
    kLmNoPqRsT();
    uVwXyZaBcD();
    eFgHiJkLmN();
}

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    print("Calling good()...");
    oPqRsTuVwX();
    print("Finished good()");
    return 0;
}
