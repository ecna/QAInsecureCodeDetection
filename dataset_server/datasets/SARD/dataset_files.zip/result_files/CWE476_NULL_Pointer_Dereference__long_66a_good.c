#include "std_testcase.h"
#include <wchar.h>

void abcdefghij(long * dataArray[]);

static void klmnopqrst()
{
    long * data;
    long * dataArray[5];
    {
        long tmpData = 5L;
        data = &tmpData;
    }
    dataArray[2] = data;
    abcdefghij(dataArray);
}

void uvwxyzabcd(long * dataArray[]);

static void efghijklmn()
{
    long * data;
    long * dataArray[5];
    data = NULL;
    dataArray[2] = data;
    uvwxyzabcd(dataArray);
}

void opqrstuvwx()
{
    klmnopqrst();
    efghijklmn();
}

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("");
    opqrstuvwx();
    printLine("");
    return 0;
}
