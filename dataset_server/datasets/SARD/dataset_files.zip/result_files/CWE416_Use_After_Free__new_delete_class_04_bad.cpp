#include "std_testcase.h"
#include <wchar.h>

namespace asdfghjklq
{
TwoIntsClass * data;
void bad()
{
    data = NULL;
    if(STATIC_CONST_TRUE)
    {
        data = new TwoIntsClass;
        data->intOne = 1;
        data->intTwo = 2;
        delete data;
    }
    if(STATIC_CONST_TRUE)
    {
        printIntLine(data->intOne);
    }
}

} /* close namespace */

using namespace asdfghjklq;

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("");
    bad();
    printLine("");
    return 0;
}
