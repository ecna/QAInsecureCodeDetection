#include "std_testcase.h"
#include <wchar.h>

void asdfghjklz()
{
    int * data;
    if(globalTrue)
    {
        data = NULL;
    }
    if(globalFalse)
    {
        printLine("");
    }
    else
    {
        if (data != NULL)
        {
            printIntLine(*data);
        }
        else
        {
            printLine("");
        }
    }
}

void qwertyuiop()
{
    int * data;
    if(globalTrue)
    {
        data = NULL;
    }
    if(globalTrue)
    {
        if (data != NULL)
        {
            printIntLine(*data);
        }
        else
        {
            printLine("");
        }
    }
}

void zxcvbnmasd()
{
    int * data;
    int tmpData = 5;
    if(globalFalse)
    {
        printLine("");
    }
    else
    {
        data = &tmpData;
    }
    if(globalTrue)
    {
        printIntLine(*data);
    }
}

void xkzjvndfgh()
{
    int * data;
    int tmpData = 5;
    if(globalTrue)
    {
        data = &tmpData;
    }
    if(globalTrue)
    {
        printIntLine(*data);
    }
}

void poiuytrewq()
{
    asdfghjklz();
    qwertyuiop();
    zxcvbnmasd();
    xkzjvndfgh();
}

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("");
    poiuytrewq();
    printLine("");
    return 0;
}