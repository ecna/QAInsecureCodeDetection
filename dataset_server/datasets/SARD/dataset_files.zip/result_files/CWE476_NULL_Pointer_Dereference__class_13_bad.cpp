#include "std_testcase.h"

namespace xkfjrjvlsd
{

void jskdfjweir()
{
    TwoIntsClass * data;
    if(GLOBAL_CONST_FIVE==5)
    {
        data = NULL;
    }
    if(GLOBAL_CONST_FIVE==5)
    {
        printIntLine(data->intOne);
        delete data;
    }
}

} /* close namespace */

using namespace xkfjrjvlsd;

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("");
    jskdfjweir();
    printLine("");
    return 0;
}
