#include "std_testcase.h"
#include <wchar.h>

static const int STATIC_CONST_TRUE = 1;
static const int STATIC_CONST_FALSE = 0;

namespace GhiJklMnoP
{
void zxcvbnmwer()
{
    char * data;
    data = NULL;
    if(STATIC_CONST_TRUE)
    {
        data = new char[100];
        delete [] data;
    }
    if(STATIC_CONST_TRUE)
    {
        delete [] data;
    }
}
} /* close namespace */

using namespace GhiJklMnoP;

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("");
    zxcvbnmwer();
    printLine("");
    return 0;
}
