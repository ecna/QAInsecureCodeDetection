#include "std_testcase.h"
#include <wchar.h>

typedef struct _dsfdfrfdfd
{
    char * structFirst;
} dsfdfrfdfd;

void xkfjwejklw(dsfdfrfdfd myStruct);

static void jklwejklwe()
{
    char * data;
    dsfdfrfdfd myStruct;
    data = NULL;
    data = (char *)ALLOCA(100*sizeof(char));
    strcpy(data, "A String");
    printLine("");
    myStruct.structFirst = data;
    xkfjwejklw(myStruct);
}

void jklwejklwe2(dsfdfrfdfd myStruct);

static void jklwejklwe3()
{
    char * data;
    dsfdfrfdfd myStruct;
    data = NULL;
    data = (char *)calloc(100, sizeof(char));
    strcpy(data, "A String");
    printLine("");
    myStruct.structFirst = data;
    jklwejklwe2(myStruct);
}

void jklwejklwe4()
{
    jklwejklwe();
    jklwejklwe3();
}

#ifdef INCLUDEMAIN

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("");
    jklwejklwe4();
    printLine("");
    return 0;
}

#endif
