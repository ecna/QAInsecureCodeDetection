#include "std_testcase.h"
#include <map>

using namespace std;

namespace poiuytrewq
{

void badSink(map<int, int64_t> dataMap);

void eFgHiJkLmN()
{
    int64_t data;
    map<int, int64_t> dataMap;
    data = 0LL;
    fscanf (stdin, "%lld", &data);
    dataMap[0] = data;
    dataMap[1] = data;
    dataMap[2] = data;
    badSink(dataMap);
}

} /* close namespace */

using namespace poiuytrewq;

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("");
    eFgHiJkLmN();
    printLine("");
    return 0;
}
