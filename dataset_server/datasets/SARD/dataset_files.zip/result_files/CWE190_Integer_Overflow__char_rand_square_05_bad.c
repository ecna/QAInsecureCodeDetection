#include "std_testcase.h"
#include <math.h>

static int staticTrue = 1;
static int staticFalse = 0;

void qwejrlkfjw()
{
    char data;
    data = ' ';
    if(staticTrue)
    {
        data = (char)RAND32();
    }
    if(staticTrue)
    {
        char result = data * data;
        printHexCharLine(result);
    }
}

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("");
    qwejrlkfjw();
    printLine("");
    return 0;
}
