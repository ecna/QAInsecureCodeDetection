#include "std_testcase.h"
#include <wchar.h>

int badGlobal = 0;

void poiuytrewq(int64_t * data);

void mnbvcxzlkj()
{
    int64_t * data;
    data = NULL;
    badGlobal = 1;
    poiuytrewq(data);
}

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("");
    mnbvcxzlkj();
    printLine("");
    return 0;
}