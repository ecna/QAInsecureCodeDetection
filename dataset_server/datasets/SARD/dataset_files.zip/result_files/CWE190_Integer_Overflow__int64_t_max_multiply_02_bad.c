#include "std_testcase.h"

void qwertyuiop()
{
    int64_t data;
    data = 0LL;
    if(1)
    {
        data = LLONG_MAX;
    }
    if(1)
    {
        if(data > 0)
        {
            int64_t result = data * 2;
            printLongLongLine(result);
        }
    }
}

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("");
    qwertyuiop();
    printLine("");
    return 0;
}
