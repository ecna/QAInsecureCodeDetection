#include "std_testcase.h"
#include <wchar.h>

static const int STATIC_CONST_TRUE = 1;
static const int STATIC_CONST_FALSE = 0;

namespace DefGhiJklM
{
static void qwertyuiop()
{
    char * data;
    data = NULL;
    if(STATIC_CONST_TRUE)
    {
        data = new char[100];
        delete [] data;
    }
    if(STATIC_CONST_FALSE)
    {
        printLine("");
    }
    else
    {
        ;
    }
}

static void asdfghjklq()
{
    char * data;
    data = NULL;
    if(STATIC_CONST_TRUE)
    {
        data = new char[100];
        delete [] data;
    }
    if(STATIC_CONST_TRUE)
    {
        ;
    }
}

static void zxcvbnmwer()
{
    char * data;
    data = NULL;
    if(STATIC_CONST_FALSE)
    {
        printLine("");
    }
    else
    {
        data = new char[100];
    }
    if(STATIC_CONST_TRUE)
    {
        delete [] data;
    }
}

static void xkfjwqzvbn()
{
    char * data;
    data = NULL;
    if(STATIC_CONST_TRUE)
    {
        data = new char[100];
    }
    if(STATIC_CONST_TRUE)
    {
        delete [] data;
    }
}

void qwertyuiop()
{
    qwertyuiop();
    asdfghjklq();
    zxcvbnmwer();
    xkfjwqzvbn();
}
} /* close namespace */

using namespace DefGhiJklM;

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("");
    qwertyuiop();
    printLine("");
    return 0;
}
