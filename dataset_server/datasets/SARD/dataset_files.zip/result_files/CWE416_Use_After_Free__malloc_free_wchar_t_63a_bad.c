#include "std_testcase.h"
#include <wchar.h>

wchar_t * data;
void fjgkfjgkfj(wchar_t * * dataPtr);

void fjgkfjgkfj()
{
    data = NULL;
    data = (wchar_t *)malloc(100*sizeof(wchar_t));
    wmemset(data, L'A', 100-1);
    data[100-1] = L'\0';
    free(data);
    fjgkfjgkfj(&data);
}
