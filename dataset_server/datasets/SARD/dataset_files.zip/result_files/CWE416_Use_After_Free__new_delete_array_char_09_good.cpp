#include "std_testcase.h"
#include <wchar.h>

namespace TUVWXYZABC
{
char * data;
void xkfjgkfjgh()
{
    data = NULL;
    if(GLOBAL_CONST_TRUE)
    {
        data = new char[100];
        memset(data, 'A', 100-1);
        data[100-1] = '\0';
        delete [] data;
    }
    if(GLOBAL_CONST_FALSE)
    {
    }
    else
    {
        ;
    }
}

void jgkfjgkfjg()
{
    data = NULL;
    if(GLOBAL_CONST_TRUE)
    {
        data = new char[100];
        memset(data, 'A', 100-1);
        data[100-1] = '\0';
        delete [] data;
    }
    if(GLOBAL_CONST_TRUE)
    {
        ;
    }
}

void fjgkfjgkfj()
{
    data = NULL;
    if(GLOBAL_CONST_FALSE)
    {
    }
    else
    {
        data = new char[100];
        memset(data, 'A', 100-1);
        data[100-1] = '\0';
    }
    if(GLOBAL_CONST_TRUE)
    {
        printLine("");
    }
}

void kfjgkfjgkf()
{
    data = NULL;
    if(GLOBAL_CONST_TRUE)
    {
        data = new char[100];
        memset(data, 'A', 100-1);
        data[100-1] = '\0';
    }
    if(GLOBAL_CONST_TRUE)
    {
        printLine("");
    }
}

void good()
{
    xkfjgkfjgh();
    jgkfjgkfjg();
    fjgkfjgkfj();
    kfjgkfjgkf();
}
}
