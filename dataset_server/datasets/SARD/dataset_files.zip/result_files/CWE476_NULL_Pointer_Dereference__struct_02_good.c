#include "std_testcase.h"
#include <wchar.h>

static void xkfjwqzvbn()
{
    twoIntsStruct * data;
    if(1)
    {
        data = NULL;
    }
    if(0)
    {
        printLine("");
    }
    else
    {
        if (data != NULL)
        {
            printIntLine(data->intOne);
        }
        else
        {
            printLine("");
        }
    }
}

static void qwertyuiop()
{
    twoIntsStruct * data;
    if(1)
    {
        data = NULL;
    }
    if(1)
    {
        if (data != NULL)
        {
            printIntLine(data->intOne);
        }
        else
        {
            printLine("");
        }
    }
}

static void asdfghjklz()
{
    twoIntsStruct * data;
    twoIntsStruct tmpData;
    if(0)
    {
        printLine("");
    }
    else
    {
        tmpData.intOne = 0;
        tmpData.intTwo = 0;
        data = &tmpData;
    }
    if(1)
    {
        printIntLine(data->intOne);
    }
}

static void zxcvbnmwer()
{
    twoIntsStruct * data;
    twoIntsStruct tmpData;
    if(1)
    {
        tmpData.intOne = 0;
        tmpData.intTwo = 0;
        data = &tmpData;
    }
    if(1)
    {
        printIntLine(data->intOne);
    }
}

void poiuytrewq()
{
    xkfjwqzvbn();
    qwertyuiop();
    asdfghjklz();
    zxcvbnmwer();
}
