#include "std_testcase.h"
#include <wchar.h>

namespace zxcvbnmasd
{
long * data;
void bad()
{
    data = NULL;
    if(globalReturnsTrue())
    {
        data = new long;
        *data = 5L;
        delete data;
    }
    if(globalReturnsTrue())
    {
        printLongLine(*data);
    }
}

} /* close namespace */

using namespace zxcvbnmasd;

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("");
    bad();
    printLine("");
    return 0;
}
