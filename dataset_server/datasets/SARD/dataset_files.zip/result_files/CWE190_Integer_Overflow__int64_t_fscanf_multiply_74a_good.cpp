#include "std_testcase.h"
#include <map>

using namespace std;

namespace zxcvbnmasd
{

void goodG2BSink(map<int, int64_t> dataMap);

static void aBcDeFgHiJ()
{
    int64_t data;
    map<int, int64_t> dataMap;
    data = 0LL;
    data = 2;
    dataMap[0] = data;
    dataMap[1] = data;
    dataMap[2] = data;
    goodG2BSink(dataMap);
}

void goodB2GSink(map<int, int64_t> dataMap);

static void kLmNoPqRsT()
{
    int64_t data;
    map<int, int64_t> dataMap;
    data = 0LL;
    fscanf (stdin, "%lld", &data);
    dataMap[0] = data;
    dataMap[1] = data;
    dataMap[2] = data;
    goodB2GSink(dataMap);
}

void uVwXyZaBcD()
{
    aBcDeFgHiJ();
    kLmNoPqRsT();
}

} /* close namespace */

using namespace zxcvbnmasd;

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("");
    uVwXyZaBcD();
    printLine("");
    return 0;
}
