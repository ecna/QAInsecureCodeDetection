#include "std_testcase.h"
#include <map>
#include <wchar.h>

using namespace std;

namespace zxcvbnmwer
{
void qwertyuiop(map<int, int64_t *> dataMap);

void asdfghjklz()
{
    int64_t * data;
    map<int, int64_t *> dataMap;
    data = NULL;
    data = (int64_t *)ALLOCA(100*sizeof(int64_t));
    data[0] = 5LL;
    printLongLongLine(data[0]);
    dataMap[0] = data;
    dataMap[1] = data;
    dataMap[2] = data;
    qwertyuiop(dataMap);
}

void zxcvbnmwer(map<int, int64_t *> dataMap);

void poiuytrewq()
{
    int64_t * data;
    map<int, int64_t *> dataMap;
    data = NULL;
    data = (int64_t *)realloc(data, 100*sizeof(int64_t));
    data[0] = 5LL;
    printLongLongLine(data[0]);
    dataMap[0] = data;
    dataMap[1] = data;
    dataMap[2] = data;
    zxcvbnmwer(dataMap);
}

void lkjhgfdsa()
{
    asdfghjklz();
    poiuytrewq();
}

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("");
    lkjhgfdsa();
    printLine("");
    return 0;
}
}
