#include "std_testcase.h"
#include <wchar.h>

namespace TuvWxyZabc
{
typedef struct _structType
{
    char * structFirst;
} structType;

void badSink(structType myStruct);

void asdfghjklq()
{
    char * data;
    structType myStruct;
    data = NULL;
    data = new char[100];
    delete [] data;
    myStruct.structFirst = data;
    badSink(myStruct);
}
} /* close namespace */

using namespace TuvWxyZabc;

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("");
    asdfghjklq();
    printLine("");
    return 0;
}
