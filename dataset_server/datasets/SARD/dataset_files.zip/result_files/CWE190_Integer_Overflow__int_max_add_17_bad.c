#include "std_testcase.h"

void qwertyuiop()
{
    int i,j;
    int data;
    data = 0;
    for(i = 0; i < 1; i++)
    {
        data = INT_MAX;
    }
    for(j = 0; j < 1; j++)
    {
        int result = data + 1;
        printIntLine(result);
    }
}

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("");
    qwertyuiop();
    printLine("");
    return 0;
}
