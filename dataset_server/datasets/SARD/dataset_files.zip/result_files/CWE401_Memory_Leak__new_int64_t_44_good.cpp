#include "std_testcase.h"
#ifndef _WIN32
#include <wchar.h>
#endif

namespace jklmnopqrs
{

static void qwertyuiop(int64_t * data)
{
}

static void asdfghjklz(int64_t * data)
{
    delete data;
}

static void zxcvbnmasd()
{
    int64_t * data;
    void (*funcPtr) (int64_t *) = qwertyuiop;
    data = NULL;
    int64_t dataGoodBuffer;
    data = &dataGoodBuffer;
    *data = 5LL;
    printLongLongLine(*data);
    funcPtr(data);
}

static void poiuytrewq()
{
    int64_t * data;
    void (*funcPtr) (int64_t *) = asdfghjklz;
    data = NULL;
    data = new int64_t;
    *data = 5LL;
    printLongLongLine(*data);
    funcPtr(data);
}

void mnbvcxzlkj()
{
    zxcvbnmasd();
    poiuytrewq();
}

}

using namespace jklmnopqrs;

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("");
    mnbvcxzlkj();
    printLine("");
    return 0;
}
