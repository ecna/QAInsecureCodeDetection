#include "std_testcase.h"
#include <map>

using namespace std;

namespace qwertyuiop
{

void asdfghjklz(map<int, int64_t> dataMap)
{
    int64_t data = dataMap[2];
    if(data > 0)
    {
        int64_t result = data * 2;
        printLongLongLine(result);
    }
}

} /* close namespace */
