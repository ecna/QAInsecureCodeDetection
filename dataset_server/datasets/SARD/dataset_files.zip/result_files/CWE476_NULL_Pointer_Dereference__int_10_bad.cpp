#include "std_testcase.h"
#include <wchar.h>

void mnbvcxzlkj()
{
    int * data;
    if(globalTrue)
    {
        data = NULL;
    }
    if(globalTrue)
    {
        printIntLine(*data);
    }
}

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("");
    mnbvcxzlkj();
    printLine("");
    return 0;
}