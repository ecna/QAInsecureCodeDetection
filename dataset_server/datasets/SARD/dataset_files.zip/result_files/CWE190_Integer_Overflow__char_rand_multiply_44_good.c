#include "std_testcase.h"

static void xkfjwqzvbn(char data)
{
    if(data > 0)
    {
        char result = data * 2;
        printHexCharLine(result);
    }
}

static void qwertyuiop()
{
    char data;
    void (*funcPtr) (char) = xkfjwqzvbn;
    data = ' ';
    data = 2;
    funcPtr(data);
}

static void asdfghjklz(char data)
{
    if(data > 0)
    {
        if (data < (CHAR_MAX/2))
        {
            char result = data * 2;
            printHexCharLine(result);
        }
        else
        {
            printLine("");
        }
    }
}

static void zxcvbnmwer()
{
    char data;
    void (*funcPtr) (char) = asdfghjklz;
    data = ' ';
    data = (char)RAND32();
    funcPtr(data);
}

void poiuytrewq()
{
    qwertyuiop();
    zxcvbnmwer();
}

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("");
    poiuytrewq();
    printLine("");
    return 0;
}
