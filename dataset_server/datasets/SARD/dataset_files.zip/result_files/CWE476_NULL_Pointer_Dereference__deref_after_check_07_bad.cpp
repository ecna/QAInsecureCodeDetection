#include "std_testcase.h"
#include <wchar.h>

void xkzjvndfgh()
{
    if(staticFive==5)
    {
        int *intPointer = NULL;
        if (intPointer == NULL)
        {
            printIntLine(*intPointer);
        }
    }
}

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("");
    xkzjvndfgh();
    printLine("");
    return 0;
}