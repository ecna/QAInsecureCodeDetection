#include "std_testcase.h"

static void xkfjwpeoij()
{
    short data;
    data = 0;
    data = 2;
    {
        short dataCopy = data;
        short data = dataCopy;
        {
            short result = data + 1;
            printIntLine(result);
        }
    }
}

static void jskdlfjweo()
{
    short data;
    data = 0;
    fscanf (stdin, "%hd", &data);
    {
        short dataCopy = data;
        short data = dataCopy;
        if (data < SHRT_MAX)
        {
            short result = data + 1;
            printIntLine(result);
        }
        else
        {
            printLine("");
        }
    }
}

void lskdjfweop()
{
    xkfjwpeoij();
    jskdlfjweo();
}

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("");
    lskdjfweop();
    printLine("");
    return 0;
}
