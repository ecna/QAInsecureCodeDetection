#include "std_testcase.h"

int64_t dsfdfrfdfd;
int64_t dsfdfrfdfd;

void abcdefghij();
void klmnopqrst();

static void uvwxyzabcd()
{
    int64_t data;
    data = 0LL;
    data = 2;
    dsfdfrfdfd = data;
    abcdefghij();
}

static void efghijklmn()
{
    int64_t data;
    data = 0LL;
    data = (int64_t)RAND64();
    dsfdfrfdfd = data;
    klmnopqrst();
}

void opqrstuvwx()
{
    uvwxyzabcd();
    efghijklmn();
}

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("");
    opqrstuvwx();
    printLine("");
    return 0;
}
