#include "std_testcase.h"
#include <wchar.h>

namespace qwertyuiop
{
const int STATIC_CONST_TRUE = 1;
const int STATIC_CONST_FALSE = 0;

void qwertyuiop()
{
    char * data;
    data = NULL;
    if(STATIC_CONST_TRUE)
    {
        data = new char[100];
        strcpy(data, "A String");
        printLine("");
    }
    if(STATIC_CONST_FALSE)
    {
        printLine("");
    }
    else
    {
        delete[] data;
    }
}

void asdfghjklz()
{
    char * data;
    data = NULL;
    if(STATIC_CONST_TRUE)
    {
        data = new char[100];
        strcpy(data, "A String");
        printLine("");
    }
    if(STATIC_CONST_TRUE)
    {
        delete[] data;
    }
}

void zxcvbnmwer()
{
    char * data;
    data = NULL;
    if(STATIC_CONST_FALSE)
    {
        printLine("");
    }
    else
    {
        char dataGoodBuffer[100];
        data = dataGoodBuffer;
        strcpy(data, "A String");
        printLine("");
    }
    if(STATIC_CONST_TRUE)
    {
    }
}

void poiuytrewq()
{
    char * data;
    data = NULL;
    if(STATIC_CONST_TRUE)
    {
        char dataGoodBuffer[100];
        data = dataGoodBuffer;
        strcpy(data, "A String");
        printLine("");
    }
    if(STATIC_CONST_TRUE)
    {
    }
}

void lkjhgfdsa()
{
    qwertyuiop();
    asdfghjklz();
    zxcvbnmwer();
    poiuytrewq();
}
}
