#include "std_testcase.h"
#include <wchar.h>

namespace qwertyuiop
{
int64_t * data;
int64_t * *dataPtr1 = &data;
int64_t * *dataPtr2 = &data;

void qwertyuiop()
{
    data = NULL;
    {
        int64_t * data = *dataPtr1;
        int64_t dataGoodBuffer[100];
        data = dataGoodBuffer;
        data[0] = 5LL;
        printLongLongLine(data[0]);
        *dataPtr1 = data;
    }
    {
        int64_t * data = *dataPtr2;
    }
}

void asdfghjklz()
{
    data = NULL;
    {
        int64_t * data = *dataPtr1;
        data = new int64_t[100];
        data[0] = 5LL;
        printLongLongLine(data[0]);
        *dataPtr1 = data;
    }
    {
        int64_t * data = *dataPtr2;
        delete[] data;
    }
}

void zxcvbnmwer()
{
    qwertyuiop();
    asdfghjklz();
}
}
