#include "std_testcase.h"
#include <wchar.h>

namespace DeFgHiJkLm
{
typedef union
{
    int64_t * unionFirst;
    int64_t * unionSecond;
} unionType;

void eFgHiJkLmN()
{
    int64_t * data;
    unionType myUnion;
    data = NULL;
    data = new int64_t[100];
    delete [] data;
    myUnion.unionFirst = data;
    {
        int64_t * data = myUnion.unionSecond;
        delete [] data;
    }
}
}
