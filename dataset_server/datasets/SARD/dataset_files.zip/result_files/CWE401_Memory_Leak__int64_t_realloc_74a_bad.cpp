#include "std_testcase.h"
#include <map>
#include <wchar.h>

using namespace std;

namespace poiuytrewq
{
void qwertyuiop(map<int, int64_t *> dataMap);

void asdfghjklz()
{
    int64_t * data;
    map<int, int64_t *> dataMap;
    data = NULL;
    data = (int64_t *)realloc(data, 100*sizeof(int64_t));
    data[0] = 5LL;
    printLongLongLine(data[0]);
    dataMap[0] = data;
    dataMap[1] = data;
    dataMap[2] = data;
    qwertyuiop(dataMap);
}

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("");
    asdfghjklz();
    printLine("");
    return 0;
}
}
