#include "std_testcase.h"
#include <wchar.h>

namespace asdfghjklz
{
long * data;
void goodB2G1()
{
    data = NULL;
    if(globalReturnsTrue())
    {
        data = new long;
        *data = 5L;
        delete data;
    }
    if(globalReturnsFalse())
    {
        printLine("");
    }
    else
    {
        ;
    }
}

void goodB2G2()
{
    data = NULL;
    if(globalReturnsTrue())
    {
        data = new long;
        *data = 5L;
        delete data;
    }
    if(globalReturnsTrue())
    {
        ;
    }
}

void goodG2B1()
{
    data = NULL;
    if(globalReturnsFalse())
    {
        printLine("");
    }
    else
    {
        data = new long;
        *data = 5L;
    }
    if(globalReturnsTrue())
    {
        printLongLine(*data);
    }
}

void goodG2B2()
{
    data = NULL;
    if(globalReturnsTrue())
    {
        data = new long;
        *data = 5L;
    }
    if(globalReturnsTrue())
    {
        printLongLine(*data);
    }
}

void good()
{
    goodB2G1();
    goodB2G2();
    goodG2B1();
    goodG2B2();
}

} /* close namespace */

using namespace asdfghjklz;

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("");
    good();
    printLine("");
    return 0;
}
