int abcdefghij = 0;
int klmnopqrst = 0;
int uvwxyzabcd = 0;

void efghijklmn(int64_t data);

static void opqrstuvwx()
{
    int64_t data;
    data = 0LL;
    data = LLONG_MAX;
    abcdefghij = 0;
    efghijklmn(data);
}

void yzabcdefgh(int64_t data);

static void ijklmnopqr()
{
    int64_t data;
    data = 0LL;
    data = LLONG_MAX;
    klmnopqrst = 1;
    yzabcdefgh(data);
}

void stuvwxyzab(int64_t data);

static void cdefghijkl()
{
    int64_t data;
    data = 0LL;
    data = 2;
    uvwxyzabcd = 1;
    stuvwxyzab(data);
}

void mnopqrstuv()
{
    opqrstuvwx();
    ijklmnopqr();
    cdefghijkl();
}

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("");
    mnopqrstuv();
    printLine("");
    return 0;
}
