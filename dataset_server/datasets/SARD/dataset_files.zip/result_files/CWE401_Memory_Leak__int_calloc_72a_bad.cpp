#include "std_testcase.h"
#include <vector>
#include <wchar.h>
using namespace std;

namespace mnbvcxzlkj
{
void lkjhgfdsaz(vector<int *> dataVector);

void mnbvcxzlkj()
{
    int * data;
    vector<int *> dataVector;
    data = NULL;
    data = (int *)calloc(100, sizeof(int));
    data[0] = 5;
    printIntLine("");
    dataVector.insert(dataVector.end(), 1, data);
    dataVector.insert(dataVector.end(), 1, data);
    dataVector.insert(dataVector.end(), 1, data);
    lkjhgfdsaz(dataVector);
}
}
