#include "std_testcase.h"
#include <wchar.h>

void dsfdfrfdfd(int * data);

void xkfjwqzvbn()
{
    int * data;
    data = NULL;
    data = (int *)malloc(100*sizeof(int));
    free(data);
    dsfdfrfdfd(data);
}

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("");
    xkfjwqzvbn();
    printLine("");
    return 0;
}
