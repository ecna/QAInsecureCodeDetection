#include "std_testcase.h"
#include <wchar.h>

namespace qwejklzxcv
{
TwoIntsClass * data;
void goodB2G1()
{
    data = NULL;
    if(STATIC_CONST_TRUE)
    {
        data = new TwoIntsClass;
        data->intOne = 1;
        data->intTwo = 2;
        delete data;
    }
    if(STATIC_CONST_FALSE)
    {
        printLine("");
    }
    else
    {
        ;
    }
}

void goodB2G2()
{
    data = NULL;
    if(STATIC_CONST_TRUE)
    {
        data = new TwoIntsClass;
        data->intOne = 1;
        data->intTwo = 2;
        delete data;
    }
    if(STATIC_CONST_TRUE)
    {
        ;
    }
}

void goodG2B1()
{
    data = NULL;
    if(STATIC_CONST_FALSE)
    {
        printLine("");
    }
    else
    {
        data = new TwoIntsClass;
        data->intOne = 1;
        data->intTwo = 2;
    }
    if(STATIC_CONST_TRUE)
    {
        printIntLine(data->intOne);
    }
}

void goodG2B2()
{
    data = NULL;
    if(STATIC_CONST_TRUE)
    {
        data = new TwoIntsClass;
        data->intOne = 1;
        data->intTwo = 2;
    }
    if(STATIC_CONST_TRUE)
    {
        printIntLine(data->intOne);
    }
}

void good()
{
    goodB2G1();
    goodB2G2();
    goodG2B1();
    goodG2B2();
}

} /* close namespace */

using namespace qwejklzxcv;

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("");
    good();
    printLine("");
    return 0;
}
