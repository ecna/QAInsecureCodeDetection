#include "std_testcase.h"
#include <wchar.h>

void lkjhgfdsaz()
{
    twoIntsStruct * data;
    if(1)
    {
        data = NULL;
    }
    if(1)
    {
        printIntLine(data->intOne);
    }
}
