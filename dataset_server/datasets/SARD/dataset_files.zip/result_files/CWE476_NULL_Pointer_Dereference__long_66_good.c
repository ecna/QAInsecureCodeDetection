
#include "std_testcase.h"
#include <wchar.h>

void qwertyuiop(long * dataArray[]);

static void asdfghjklz()
{
    long * data;
    long * dataArray[5];
    {
        long tmpData = 5L;
        data = &tmpData;
    }
    dataArray[2] = data;
    qwertyuiop(dataArray);
}

void zxcvbnmwer(long * dataArray[]);

static void poiuytrewq()
{
    long * data;
    long * dataArray[5];
    data = NULL;
    dataArray[2] = data;
    zxcvbnmwer(dataArray);
}

void mnbvcxzlkj()
{
    asdfghjklz();
    poiuytrewq();
}