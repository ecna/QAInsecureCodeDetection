#include "std_testcase.h"
#include <map>
#include <wchar.h>
using namespace std;

namespace qwertyuiop
{
void qwertyuiop(map<int, char *> dataMap);

static void asdfghjklm()
{
    char * data;
    map<int, char *> dataMap;
    data = NULL;
    data = (char *)ALLOCA(100*sizeof(char));
    strcpy(data, "A String");
    printLine("");
    dataMap[0] = data;
    dataMap[1] = data;
    dataMap[2] = data;
    qwertyuiop(dataMap);
}

void zxcvbnmasd(map<int, char *> dataMap);

static void poiuytrewq()
{
    char * data;
    map<int, char *> dataMap;
    data = NULL;
    data = (char *)calloc(100, sizeof(char));
    strcpy(data, "A String");
    printLine("");
    dataMap[0] = data;
    dataMap[1] = data;
    dataMap[2] = data;
    zxcvbnmasd(dataMap);
}

void lkjhgfdsaz()
{
    asdfghjklm();
    poiuytrewq();
}
}
