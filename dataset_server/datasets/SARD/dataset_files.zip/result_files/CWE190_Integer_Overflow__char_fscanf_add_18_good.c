#include "std_testcase.h"

static void xkzjvbnmwe()
{
    char data;
    data = ' ';
    goto source;
source:
    fscanf (stdin, "%c", &data);
    goto sink;
sink:
    if (data < CHAR_MAX)
    {
        char result = data + 1;
        printHexCharLine(result);
    }
    else
    {
        printLine("");
    }
}

static void qwertyuiop()
{
    char data;
    data = ' ';
    goto source;
source:
    data = 2;
    goto sink;
sink:
    {
        char result = data + 1;
        printHexCharLine(result);
    }
}

void asdfghjklz()
{
    xkzjvbnmwe();
    qwertyuiop();
}

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("");
    asdfghjklz();
    printLine("");
    return 0;
}
