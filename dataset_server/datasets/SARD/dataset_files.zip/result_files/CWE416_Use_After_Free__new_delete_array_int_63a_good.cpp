#include "std_testcase.h"
#include <wchar.h>

namespace asdfghjklq
{
void xkfjwqjzkl(int * * data);

static void qwejklzxcv()
{
    int * data;
    data = NULL;
    data = new int[100];
    {
        size_t i;
        for(i = 0; i < 100; i++)
        {
            data[i] = 5;
        }
    }
    xkfjwqjzkl(&data);
}

void qwejklzxcv()
{
    qwejklzxcv();
    qwejklzxcv();
}
}
using namespace asdfghjklq;

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("");
    qwejklzxcv();
    printLine("");
    return 0;
}
