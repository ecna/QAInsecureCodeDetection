#include "std_testcase.h"

namespace dsfdfrfdfd
{
void xkfjweirue()
{
    int64_t data;
    int64_t &dataRef = data;
    data = 0LL;
    data = 2;
    {
        int64_t data = dataRef;
        if(data > 0)
        {
            int64_t result = data * 2;
            printLongLongLine(result);
        }
    }
}

void jdkfjsldkf()
{
    int64_t data;
    int64_t &dataRef = data;
    data = 0LL;
    data = (int64_t)RAND64();
    {
        int64_t data = dataRef;
        if(data > 0)
        {
            if (data < (LLONG_MAX/2))
            {
                int64_t result = data * 2;
                printLongLongLine(result);
            }
            else
            {
                printLine("");
            }
        }
    }
}

void qwejrlkfjw()
{
    xkfjweirue();
    jdkfjsldkf();
}
} /* close namespace */

using namespace dsfdfrfdfd;

int main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("");
    qwejrlkfjw();
    printLine("");
    return 0;
}
